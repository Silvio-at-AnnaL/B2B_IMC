# ANNA-lyst — B2B Industrial Matchmaking Platform

Scaffold **v0.1.1** · Next.js 15 (App Router, TypeScript) · Drizzle ORM · Neon (PostgreSQL) · Auth.js · Tailwind (CI-Farben hinterlegt)

## Architekturprinzipien

1. **Eine** Umgebungsvariable für die Infrastruktur: `DATABASE_URL` (plus zwei Secrets für Verschlüsselung/Sessions). **Alles andere** — LLM-Keys, Mailserver, Serper, Hunter/Apollo, IndustryStock, diribo, wlw — wird verschlüsselt in der DB gespeichert und ausschließlich im Admin-Bereich verwaltet. Kein IT-Profi muss in den Quellcode.
2. **Labelverwaltung Multilang:** jeder UI-Text ist ein Label (`labels` / `label_translations`). Fallback-Kette: Zielsprache → Englisch → Label-Key sichtbar. Eine Sprache erscheint im Frontend, sobald ein einziges Label in ihr existiert.
3. **Credits als Ledger**, Geldbeträge in Cents, Rechnungsnummern eindeutig (GoBD).
4. **DSGVO by design:** jede gefundene Person trägt Quelle + Quell-URL; Löschregister (`erasure_registry`) unterdrückt gelöschte Personen in künftigen Suchen. ⚠️ Die Rechtsgrundlage (Art. 6 lit. f Abwägung, Art.-14-Informationskonzept) ist **vor Launch anwaltlich zu klären** — siehe Projektaudit.
5. **Prompts versioniert** (`prompt_versions`), genau eine aktive Version je Prompt; Änderung ohne Deployment.
6. **Quellen-Adapter:** jede Datenquelle (Suche, Kontaktdaten, Verzeichnisse) ist ein Eintrag in `integrations` und wird im Admin aktiviert/konfiguriert.

## Setup (DEV)

```bash
npm install
cp .env.example .env
# 1. Neon-Projekt anlegen (https://neon.tech, Region EU) → Connection String in DATABASE_URL
# 2. openssl rand -hex 32     → APP_ENCRYPTION_KEY
# 3. openssl rand -base64 32  → AUTH_SECRET
npm run db:push     # Schema in die Neon-DB schreiben (DEV; später: db:generate + db:migrate)
npm run db:seed     # Sprachen, Pläne, Prompts, Labels, Integrations-Platzhalter, Admin-User
npm run dev         # http://localhost:3000
```

Initialer Admin: `admin@anna-lyst.local` / `change-me-now` (oder `SEED_ADMIN_PASSWORD` setzen). **Sofort ändern.**

## GitHub & Versionierung (Anweisung 6 + 7)

Einmalig (im Projektordner):

```bash
git init && git add -A && git commit -m "scaffold v0.1.0"
git remote add origin git@github.com:<account>/annalyst-platform.git
git push -u origin main
```

Danach: jede Änderung als Commit; Schemaänderungen erzeugen versionierte Migrationsdateien unter `drizzle/` (`npm run db:generate`). Issues laufen über das GitHub-Repo.

## Replit-Workflow (DEV & Vorschau, Anweisung 8)

Entschieden: Entwicklung und Vorschau laufen in **Replit**.

1. Repl aus dem GitHub-Repo erzeugen (Import from GitHub) — so bleiben GitHub-Versionierung und Issues führend.
2. **Datenbank:** Replits eingebautes PostgreSQL ist eine Neon-Instanz und erfüllt die NEON-Vorgabe direkt; alternativ externe Neon-DB. In beiden Fällen nur `DATABASE_URL` in den Replit-Secrets setzen.
3. `APP_ENCRYPTION_KEY` und `AUTH_SECRET` ebenfalls als Replit-Secrets (nie in Dateien).
4. `npm run db:push && npm run db:seed`, dann `npm run dev` — die Replit-Dev-URL ist der Vorschaulink.
5. Für stabile Vorschau-Stände: Replit Deployments (Autoscale) auf den jeweiligen Stand.
6. Claude überwacht das Coding: Änderungen laufen über Commits ins GitHub-Repo, Replit zieht sie nach (`git pull` im Repl oder GitHub-Sync).

## Struktur

```
src/db/schema/index.ts   Gesamtes Datenmodell (Auth, CRM, Verträge/Rechnungen,
                         Credits, Suchen, Labels/i18n, Prompts/LLM, Integrationen,
                         SEO/robots/llms.txt, Audit, DSGVO-Löschregister)
src/db/seed.ts           DEV-Seed
src/lib/crypto.ts        AES-256-GCM für DB-gespeicherte Credentials
src/lib/i18n/labels.ts   Label-Resolver mit EN-Fallback
src/lib/settings.ts      Key-Value-Settings (robots.txt, llms.txt, Meta-Defaults)
src/auth.ts              Auth.js (Rollen: admin / staff / customer)
src/middleware.ts        Zugriffsschutz /admin und /account
src/app/robots.txt/      Dynamisch aus DB
src/app/llms.txt/        Dynamisch aus DB
src/app/admin/           Verwaltungsbereich (Navigationsgerüst, Sektionen folgen)
src/app/account/         Kundenbackend (Navigationsgerüst, Sektionen folgen)
```

## Roadmap

- **Phase 1:** Such-Pipeline (Scraping → Prompt-Chain → Quellen-Adapter → Scoring), Suchformular, Ergebnisseite, Credit-Abbuchung
- **Phase 2:** Admin-CRUD: Kunden/CRM, Verträge, Rechnungen, Labels, Prompts, LLM, Integrationen, SEO
- **Phase 3:** Kundenbackend-Funktionen, Mailversand, Exporte, Rechnungs-PDF
- **Phase 4:** Landing-Page-Design (CI), Onboarding, Free-Tier-Schutz, Monitoring

## Kontaktdaten: Enrichment-Kaskade (entschieden)

Pro Ergebnis von kostenlos nach teuer, Abbruch sobald ein Kontakt steht; Reihenfolge im Admin über `integrations.cascade_priority` umsortierbar:

1. Verzeichnis-APIs: diribo (`https://api.diribo.com/v1/de`), IndustryStock, später wlw — eigener Zugang, Grenzkosten ≈ 0
2. Eigenes Website-Scraping der Kandidaten-Firma (Impressum/Team/Kontakt) + LLM-Extraktion — nur Token-Kosten
3. Unipile (LinkedIn, vorhandener Zugang) — Hinweis: läuft über das eigene LinkedIn-Konto, ToS-Risiko liegt beim Konto
4. Optional je Plan zuschaltbar: Hunter.io als E-Mail-Finder/-Verifizierer für Restlücken

Free-Tier ohne Stufen 3+4, Kontaktdaten verpixelt (`plans.includes_contact_data = false`).

## GAIO-Blueprint: Übernahmen & Abweichungen

| GAIO | Hier |
|---|---|
| `settings` KV + `is_encrypted`-Empfehlung | übernommen: `settings.is_encrypted`, get/setSetting ver-/entschlüsseln transparent |
| `ai_provider` / `ai_api_key_*` / `ai_model_*` (10 Keys) | eigene Tabelle `llm_providers` (mehrere Provider parallel, Keys verschlüsselt) — strukturierter als KV |
| `mail_*` (7 Keys) | `integrations` (key=`smtp`): Passwort verschlüsselt, Rest in `config` |
| `database_url` in settings | **nicht übernommen** (GAIO-Empfehlung 2): nur ENV/Replit-Secret |
| `branding_*` / `theme_*` / `contact_*` | settings-Keys `branding`, `theme`; Logo als Datei-Verweis statt base64 (GAIO-Empfehlung 3) |
| `permissions_json` | übernommen als settings-Key (Feinrechte je Rolle, Rollen: admin/staff/customer) |
| `users` (must_change_pw, created_by, bcrypt) | übernommen: `must_change_pw`, `created_by_user_id`, bcrypt |
| `verification_codes` | übernommen |
| `prompts` (template, is_modified, reset) | `prompts` + `prompt_versions`: Versionierung statt is_modified/reset — Rollback auf jede Version |
| `shared_analyses` + `share_access_log` | `shared_searches` + `share_access_log` |
| `analysis_log` / `analysis_exports` | `searches`/`audit_log` + `search_exports` |
| `delivery_*` (Versand) | folgt mit dem Mailversand (Phase 3) |

## Bewusst offen / zu klären

- Rechtsgutachten Kontaktdaten: Art.-14-Informationskonzept bleibt nötig, auch bei eigenen Quellen — blockiert den Launch, nicht die Entwicklung
- diribo- und IndustryStock-API: Zugangsdaten + Endpunkt-Doku bereitstellen, dann werden die Adapter implementiert
- wlw: kein bekannter API-Zugang — Adapter bleibt inaktiv
- Preistabelle ist Erstüberlegung; Schema (`plans`, `contracts` mit Overrides) trägt jede spätere Änderung
- Zahlungsabwicklung (Stripe vs. Rechnung manuell) — Schema unterstützt beides
