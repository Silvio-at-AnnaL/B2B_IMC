/**
 * Seed-Daten fuer die DEV-Umgebung.
 * Ausfuehren: npm run db:seed  (DATABASE_URL muss gesetzt sein)
 */
import "dotenv/config";
import bcrypt from "bcryptjs";
import { db } from "./index";
import {
  languages, plans, prompts, promptVersions, integrations, labels,
  labelTranslations, users, settings,
} from "./schema";

async function main() {
  // --- Sprachen ---
  await db.insert(languages).values([
    { code: "en", name: "English" },
    { code: "de", name: "Deutsch" },
  ]).onConflictDoNothing();

  // --- Plaene (aus dem Konzept; Enterprise-Preis = auf Anfrage => null) ---
  await db.insert(plans).values([
    { code: "free", name: "Free", monthlyCredits: 3, resultsPerSearch: 5, includesContactData: false, priceCents: 0 },
    { code: "starter", name: "Starter", monthlyCredits: 20, resultsPerSearch: 20, priceCents: 4900 },
    { code: "pro", name: "Pro", monthlyCredits: 100, resultsPerSearch: 50, priceCents: 14900 },
    { code: "enterprise", name: "Enterprise", monthlyCredits: null, resultsPerSearch: 100, priceCents: null },
  ]).onConflictDoNothing();

  // --- Prompt-Chain (3 Schritte aus dem Konzept, versioniert) ---
  await db.insert(prompts).values([
    { key: "context_extraction", name: "Schritt 1 — Unternehmenskontext extrahieren" },
    { key: "search_strategy", name: "Schritt 2 — Suchstrategie ableiten" },
    { key: "scoring", name: "Schritt 3 — Partnerrecherche & Scoring" },
  ]).onConflictDoNothing();

  await db.insert(promptVersions).values([
    {
      promptKey: "context_extraction", version: 1, active: true,
      systemText:
        "Du bist ein B2B-Marktanalyst. Analysiere die Website eines Unternehmens und extrahiere: " +
        "Branche (NACE-Code wenn moeglich), Hauptprodukte/Dienstleistungen, Zertifizierungen (ISO, IATF, ...), " +
        "Positionierung (Nische, Massenmarkt, Premium), Hinweise auf bestehende Maerkte. " +
        "Antworte ausschliesslich als JSON-Objekt.",
      userTemplate: "Website-Inhalt:\n{{scraped_text}}",
    },
    {
      promptKey: "search_strategy", version: 1, active: true,
      systemText:
        "Du bist ein B2B-Vertriebsstratege. Leite aus Unternehmensprofil, Modus, Produkt und Zielregion ab: " +
        "relevante Suchbegriffe (Deutsch + Englisch + Landessprache), Zielunternehmensprofil (Branche, Groesse, Typ), " +
        "relevante Berufsbezeichnungen der Ansprechpartner, empfohlene Quellen (Branchenverbaende, Messen, Register). " +
        "Antworte ausschliesslich als JSON-Objekt.",
      userTemplate:
        "Unternehmensprofil: {{company_profile_json}}\nModus: {{mode}}\nProdukt: {{product}}\nZielregion: {{target_region}}",
    },
    {
      promptKey: "scoring", version: 1, active: true,
      systemText:
        "Du wertest Suchergebnisse aus und bewertest potenzielle Geschaeftspartner. " +
        "Kriterien: Produktrelevanz, Laendermatch, Unternehmensgroesse, Kontaktverfuegbarkeit. " +
        "Skala 0-100 mit Begruendung in 1-2 Saetzen in der Sprache {{output_lang}}. " +
        "Antworte ausschliesslich als JSON-Array.",
      userTemplate: "Kandidaten:\n{{candidates_json}}",
    },
  ]).onConflictDoNothing();

  // --- Integrations-Platzhalter (Keys werden im Admin-UI hinterlegt) ---
  // Enrichment-Kaskade: kleine Prioritaet = zuerst; bricht je Ergebnis ab,
  // sobald ein Kontakt steht. Reihenfolge im Admin umsortierbar.
  await db.insert(integrations).values([
    { key: "serper", name: "Serper (Google Search API)", kind: "search_api", baseUrl: "https://google.serper.dev", cascadePriority: 100 },
    { key: "diribo", name: "diribo", kind: "directory", baseUrl: "https://api.diribo.com/v1/de", cascadePriority: 10 },
    { key: "industrystock", name: "IndustryStock", kind: "directory", cascadePriority: 11 },
    { key: "wlw", name: "Wer liefert was (Visable)", kind: "directory", cascadePriority: 12 },
    { key: "website_scraping", name: "Eigenes Website-Scraping (Impressum/Team/Kontakt)", kind: "scraper", cascadePriority: 20, active: true },
    { key: "unipile", name: "Unipile (LinkedIn)", kind: "contact_data", baseUrl: "https://api.unipile.com", cascadePriority: 30 },
    { key: "hunter", name: "Hunter.io (E-Mail-Finder/Verifizierung, optional)", kind: "contact_data", baseUrl: "https://api.hunter.io", cascadePriority: 40 },
    { key: "smtp", name: "Mailserver (SMTP)", kind: "mail" },
  ]).onConflictDoNothing();

  // --- Basis-Labels (en = Pflicht-Fallback, de) ---
  const baseLabels: [string, string, string][] = [
    // [key, en, de]
    ["nav.home", "Home", "Start"],
    ["nav.dashboard", "Dashboard", "Übersicht"],
    ["search.mode.seller", "I am selling — find new markets", "Ich verkaufe — neue Absatzmärkte finden"],
    ["search.mode.buyer", "I am buying — find new suppliers", "Ich kaufe ein — neue Lieferanten finden"],
    ["search.field.company", "Company name", "Unternehmensname"],
    ["search.field.url", "Website URL", "Website-URL"],
    ["search.field.product", "Product / product group", "Produkt / Produktgruppe"],
    ["search.field.region", "Target country / region", "Zielland / Zielregion"],
    ["search.submit", "Find partners", "Partner finden"],
  ];
  await db.insert(labels)
    .values(baseLabels.map(([key]) => ({ key })))
    .onConflictDoNothing();
  await db.insert(labelTranslations)
    .values(baseLabels.flatMap(([key, en, de]) => [
      { labelKey: key, langCode: "en", value: en },
      { labelKey: key, langCode: "de", value: de },
    ]))
    .onConflictDoNothing();

  // --- robots.txt / llms.txt Defaults ---
  await db.insert(settings).values([
    { key: "robots_txt", value: "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /account/" },
    { key: "llms_txt", value: "# ANNA-lyst\n\nAI-powered B2B industrial matchmaking platform." },
    // Theme-Defaults aus der CI (GAIO: theme_*); Logo kommt als Datei-Verweis, nicht base64
    { key: "theme", value: { primary: "#1D71B8", accent: "#EB9234", green: "#428A44", red: "#D94235", gray: "#878787", colorblindMode: false } },
    { key: "branding", value: { logoUrl: "/logo.png", footerText: "ANNA Lyst GmbH", footerUrl: "" } },
    // Rollen->Rechte-Mapping (GAIO: permissions_json); Feinrechte je Admin-Modul
    { key: "permissions_json", value: {
      admin: ["*"],
      staff: ["customers:*", "searches:read", "labels:*", "seo:*", "invoices:read"],
      customer: ["account:*"],
    } },
  ]).onConflictDoNothing();

  // --- Initialer Admin (Passwort SOFORT nach erstem Login aendern) ---
  const initialPassword = process.env.SEED_ADMIN_PASSWORD ?? "change-me-now";
  await db.insert(users).values({
    email: "admin@anna-lyst.local",
    passwordHash: await bcrypt.hash(initialPassword, 12),
    firstName: "Initial",
    lastName: "Admin",
    role: "admin",
    mustChangePw: true, // erzwungener Wechsel beim ersten Login (GAIO-Muster)
  }).onConflictDoNothing();

  console.log("Seed abgeschlossen. Admin: admin@anna-lyst.local / " +
    (process.env.SEED_ADMIN_PASSWORD ? "(SEED_ADMIN_PASSWORD)" : "change-me-now — bitte sofort ändern."));
}

main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
